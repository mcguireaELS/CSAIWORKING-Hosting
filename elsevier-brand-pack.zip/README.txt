Elsevier brand pack for Claude
==============================

Upload the contents of this pack into your Claude chat before asking for any
branded output. Claude cannot keep files between sessions, so this is a per
session step.

WHAT IS IN HERE

brand-screenshots/
    Screenshots of the brand standards: branding, typography, color, and data
    visualization. Upload these so Claude can see the standards directly.

web-fonts/
    The six Elsevier web fonts as woff2 files. Use these for HTML work. Claude
    puts them in a /fonts folder and wires them up with @font-face.

logos/
    The official logo in three lockups (primary, stacked, wordmark only), each
    in graphite, vital orange, and white, as SVG and PNG.

A NOTE ON FONTS

Tiempos Text and National 2 are the standard typefaces.
Georgia and Arial are Microsoft availability fallbacks only, used when the real
fonts are not installed. Uploading the real files is what stops Claude from
quietly shipping the fallback.

For PowerPoint you need the .ttf or .otf versions instead, because PowerPoint
cannot use woff2. Those are not in this pack yet.

A NOTE ON LOGOS

Use SVG for anything on screen, since it stays sharp at any size. The PNGs are
print resolution and are better suited to PowerPoint.

Pick the lockup to fit the space: primary is horizontal, stacked is for square
or vertical placements, and the wordmark alone is for tight spaces.

Pick the color to fit the background: graphite or vital orange on light
backgrounds, white on dark or orange backgrounds.

Do not recolor, stretch, or redraw the mark, and do not crop the tree out of a
lockup to make a standalone icon. Keep clear space around it.
